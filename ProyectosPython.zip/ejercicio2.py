opcion = 0

while(opcion != 5):
    print("-------------------------------------")
    print("Calculadora saludable")
    print("-------------------------------------")
    print("1. Peso ideal")
    print("2. Calorias quemadas")
    print("3. Porcentaje de grasa corporal")
    print("4. Indice metabolico basal")
    print("5. Salir")

    opcion = int(input("Seleccione una opción: "))

    if opcion == 1:
        estatura = int(input("Digite su altura en cm: "))
        
        genero = ""
        while(genero != "F" and genero != "M"):
            genero = input("Digite su genero, F: Femenino, M: Masculino: ")
            genero = genero.upper()

        if genero == "M" :
            resultado = 56.2 +1.41*(estatura/2.54 -60)            
        else:
            resultado = 53.1 +1.36*(estatura/2.54 -60)
            
        print("Su peso ideal es: ", round(resultado, 2))
        
    elif opcion == 2:
        print("TODO")
    elif opcion == 3:
        print("TODO")
    elif opcion == 4:
        print("TODO")
    elif opcion == 5:
        print("TODO")
    else:
        print("Opción no valida")

