import utilidades as u
from time import sleep

opcion = 0

while(opcion != 5):
    print("-------------------------------------")
    print("Calculadora saludable")
    print("-------------------------------------")
    print("1. Peso ideal")
    print("2. Calorias quemadas")
    print("3. Porcentaje de grasa corporal")
    print("4. Indice metabolico basal")
    print("5. Salir")

    opcion = int(input("Seleccione una opción: "))
    u.clear()

    if opcion == 1:
        estatura = int(input("Digite su altura en cm: "))
        genero = input("Digite su genero (M) Masculino, (F) Femenino: ")
        resultado = u.peso_ideal(estatura, genero)        
        print(f'El peso ideal para su estatura es: {resultado} ')        
    elif opcion == 2:
        met = int(input("1. Caminar, 2. Tenis, 3. Bicicleta, 4. Correr, 5. Nadar: "))
        minutos = int(input("Digite los minutos de su actividad: "))
        kg = float(input("Digite su peso en Kg: "))        
        resultado = u.calorias_quemadas(minutos, kg, met)        
        print(f'Las calorias quedmas para el deporte seleccionado es: {resultado} ')
    elif opcion == 3:
        print("TODO")
    elif opcion == 4:
        print("TODO")
    elif opcion == 5:
        print("Saliendo de la aplicación....")
    else:
        print("Opción valida")
    
    sleep(5)
    u.clear()
    