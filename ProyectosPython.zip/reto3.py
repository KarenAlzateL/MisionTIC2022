texto = "juankzm123jfkdsj fkajsk dfjaskdjfak"

#Obtener la cantidad de elementos de un texto
x = texto.__len__()

print("Cantidad de elementos: ", x)

print(texto[0])
print(texto[1])
print(texto[2])
print(texto[3])
print(texto[4])
print(texto[9])

for car in texto:
    print(car)