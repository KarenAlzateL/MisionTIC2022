codigo = "hgasfhjhjf"

print("cantidad de caracteres: ", codigo.__len__() )
print("cantidad de caracteres: ", len(codigo) )

x = codigo[-3]
print("ultimo elemento: ",x)

y = 0
for car in codigo:
    y = y + 1

print(y)