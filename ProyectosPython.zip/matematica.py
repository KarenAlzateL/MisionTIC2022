from math import cos
import utilidades

global_x = 10

def funcion_test():
    local_x = 20 + global_x
    return local_x

x =  round(cos(5), 4)

print(f"el coseno de 5 es {x}")

print("variable global ", global_x)
print("variable local de función ", funcion_test() )
print(utilidades._PI)

help(utilidades.__doc__)