""" Modulo de funciones para el calculo de peso ideal, calorias quemadas"""
from os import system, name

_PI = 3.1416

def peso_ideal(estatura: int, genero: str) -> float:
    """ 
    Función para calcular el peso ideal de una persona basado en su estatura y genero

    Parameters
    ----------
    estatura : int
        Estatura en centimetros
    genero : str
        M: Masculino, F: Femenino
    
    Returns
    -------
    peso_ideal:float
        Calculo del peso ideal
    """  
    if genero == "M":
        return ( 56.2 +1.41*(estatura/2.54 -60) )
    else:
        return ( 53.1 +1.36*(estatura/2.54 -60) )

def calorias_quemadas(minutos: int, kg: float, met: int) -> float:
    
    if met == 1:
        valor_met = 2
    elif met == 2: 
        valor_met = 5
    elif met == 3: 
        valor_met = 14
    elif met == 4: 
        valor_met = 6
    elif met == 5: 
        valor_met = 9.8
    else:
        valor_met = 1

    return ( minutos * valor_met * kg ) / 200

def clear():
  
    if name == 'nt':
        _ = system('cls')  
    else:
        _ = system('clear')