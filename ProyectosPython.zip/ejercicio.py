import Modulos.modulos as modulos

opcion = 0

while(opcion != 5):
    print("-------------------------------------")
    print("Calculadora saludable")
    print("-------------------------------------")
    print("1. Peso ideal")
    print("2. Calorias quemadas")
    print("3. Porcentaje de grasa corporal")
    print("4. Indice metabolico basal")
    print("5. Salir")

    opcion = int(input("Seleccione una opción: "))

    if opcion == 1:
        estatura = int(input("Digite su estatura en cm: "))
        genero = ""
        while(genero.upper() != "F" and genero.upper() != "M"):
            genero = input("Digite F: Femenino, M: Masculino : ")
            
        resultado = modulos.peso_ideal(estatura,genero)

        if resultado != -1:
            print(f"Su peso ideal es: {resultado} Kgs")
        else:
            print("Genero no valido")

    elif opcion == 2:
        met = 0
        while(met <= 0 or met > 5):
            met = int(input("""
                Indique el met con un numero:
                1. Caminar
                2. Nadar
                3. Correr
                4. Tenis
                5. Montar bicicleta
                """))    

        minutos = int(input("Digite los minutos de su actividad: "))
        kg = float(input("Digite su peso en Kg: "))

        resultado = modulos.calorias_quemadas(minutos, met, kg)
        print("Las calorias quemadas son: ", resultado)

    elif opcion == 3:
        print("imc")
    elif opcion == 4:
        print("indice matabolico")
    elif opcion == 5:
        print("Saliendo de la aplicación...")
    else:
        print("La opción no valida")