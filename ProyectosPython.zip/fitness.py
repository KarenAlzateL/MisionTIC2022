def peso_ideal(estatura, genero):
    if genero.upper() == "F":
        resultado = 53.1 +1.36 *(estatura/2.54 -60)
    elif genero.upper() == "M":
        resultado = 56.2 +1.41 *(estatura/2.54 -60)
    else:
        resultado = -1

    return resultado

def calorias_quemadas(tiempo, peso, met):
    
    if met == 1 :
        valor_met = 2
    elif met == 2:
        valor_met = 9.8
    elif met == 3:
        valor_met = 6
    elif met == 4:
        valor_met = 5
    elif met == 5:
        valor_met = 14
    else:
        valor_met = 1

    resultado = (tiempo * valor_met * peso) /200

    return resultado